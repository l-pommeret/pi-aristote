# Instructions pour l'assistant

## Projet

TP « vibe coding » de l'école d'automne EcAuTAL 2026 (LISN). Une personne en master ou en thèse de TAL te pilote
pour construire, palier par palier, un petit outil pour le grec ancien sur le corpus de `corpus/` (Homère, Platon,
Xénophon, Lysias : 9 textes, 41 000 mots). Elle ne programme pas forcément : explique brièvement ce que tu fais,
en français, et montre les résultats.

## Lancer

```bash
python3 tests/palier1.py       # le test d'un palier (palier1 à palier5)
python3 tests/tout.py          # le bilan de tous les paliers
```

Un palier est fini quand son test affiche « réussi ». Lance le test après chaque modification.

## Structure

- `corpus/` : **lecture seule** (les tests vérifient son empreinte). `corpus/metadonnees.json` liste les textes
  (champs `id`, `auteur`, `oeuvre`, `abreviation`, `fichier`…). `corpus/textes/<id>.txt` : une ligne par segment,
  `référence<TAB>texte`, UTF-8. `corpus/lexique/lsj_vedettes.txt` : une vedette du LSJ par ligne.
- `tests/` : **ne jamais modifier**. Lis-les quand un test échoue : ils sont la définition du travail.
- `sorties/`, `cache/` : fichiers produits par les scripts.
- À la racine, les fichiers que tu crées, palier par palier (ci-dessous).

## Conventions

- Python 3.8 ou plus, **bibliothèque standard uniquement** (pas de pip, pas de uv, pas de cltk, pas de regex).
  JavaScript sans dépendance ni étape de build.
- Toujours `encoding="utf-8"` pour lire et écrire. Messages, sorties et commentaires en français.
- Réutilise `grec.py` (palier 1) dans les paliers suivants plutôt que de recopier la normalisation.

## Normaliser le grec (vaut pour tous les paliers)

`normaliser(mot)` : (1) NFC ; (2) toute apostrophe d'élision (`'` U+0027, `ʼ` U+02BC, `᾽` U+1FBD, `᾿` U+1FBF,
`΄` U+0384, `´` U+00B4) devient `’` (U+2019) ; (3) l'accent grave devient aigu (en NFD, U+0300 → U+0301,
puis NFC) ; (4) minuscules ; (5) un σ en fin de mot devient ς. Les esprits, les autres accents, l'iota souscrit
et le tréma sont gardés.
Un **mot** est une suite de lettres et de diacritiques, éventuellement suivie d'une apostrophe (`δ’`, `ἀλλ’`) ;
tout le reste (ponctuation, `·`, `;`, `—`, crochets, chiffres) sépare les mots. Attention : en NFD, `\w` ne
reconnaît pas les diacritiques, et en JavaScript `\w` ne reconnaît aucune lettre grecque (utiliser `\p{L}` avec
le drapeau `u`).
Option `sans_accents` : retirer en plus tous les diacritiques (NFD puis suppression des caractères combinants).

## Les paliers

1. **Fréquences.** `grec.py` définit `normaliser(mot, sans_accents=False)` et `mots(texte, sans_accents=False)`
   (liste des mots normalisés). `frequences.py [--top N] [--texte ID ...] [--sans-accents]` affiche une ligne
   `mot<TAB>compte` par mot, du plus fréquent au moins fréquent (`--top 20` par défaut, tout le corpus sans `--texte`).
2. **Concordance.** `concordance.py` définit `concordance(requete, contexte=5, textes=None, sans_accents=False)`,
   qui renvoie une liste de dicts `{"texte": id, "ref": référence, "gauche": str, "mot": str, "droite": str}` :
   les `contexte` mots avant et après, sans ponctuation, en continuant sur les lignes voisines du même texte.
   La requête est normalisée comme le texte ; terminée par `*`, c'est un préfixe (`ψυχ*`), sans la règle du
   sigma final (`Ὀδυσσ*` doit trouver `Ὀδυσσέα`).
   En ligne de commande : `python3 concordance.py ψυχή [--contexte N] [--texte ID]` affiche une ligne par
   occurrence avec la référence (`Pl. Ap. 28d` : `abreviation` + référence).
3. **Page web.** `construire_site.py` écrit `site/donnees.js` (`const CORPUS = …` : les textes et leurs lignes).
   `site/recherche.js` définit `chercher(corpus, requete, options)` (options `contexte`, `sansAccents`), qui renvoie
   les mêmes objets qu'au palier 2, avec la même normalisation ; ce fichier ne contient que des fonctions
   (aucun accès au DOM au chargement). `site/index.html` charge `donnees.js` puis `recherche.js` par des
   `<script src>` classiques (pas de `type="module"`, pas de `fetch` : la page doit marcher en double-cliquant
   dessus, en `file://`), propose un champ de recherche et affiche les résultats.
4. **Lemmatisation par Aristote.** `python3 lemmatiser.py FICHIER > sorties/palier4.tsv` lemmatise un texte
   (une phrase par ligne) : une ligne d'en-tête `forme<TAB>lemme<TAB>lsj`, puis une ligne par mot, dans l'ordre,
   `lsj` valant `oui` si le lemme est une vedette de `corpus/lexique/lsj_vedettes.txt` (comparaison en NFC,
   accent grave → aigu, sans macron ni brève, sans numéro d'homonyme, sans tenir compte de la casse), `non` sinon.
   - API compatible OpenAI : `POST https://llm.aristote.education/v1/chat/completions`, en-tête
     `Authorization: Bearer <clé>`, `urllib.request`, `temperature` 0, `max_tokens` au plus 2000, délai 180 s,
     quelques nouvelles tentatives sur 429/5xx ou réponse vide. Modèle par défaut `qwen-3.6-35b-instruct`
     (option `--modele`).
   - Clé : lue dans `~/.pi/agent/auth.json` (`["aristote"]["key"]`), sinon `$ARISTOTE_API_KEY`.
     **Ne jamais l'afficher, l'écrire dans un fichier, la mettre dans le code ni lancer une commande qui la montre**
     (pas de `cat auth.json`) ; masquer `sk-…` dans les messages d'erreur.
   - Chaque appel est ajouté à `cache/aristote.jsonl` (une ligne JSON : `modele`, `messages`, `reponse` brute) et
     réutilisé si la même requête revient.
   - Si un lemme n'est pas une vedette du LSJ, relancer le modèle une fois en lui donnant les vedettes proches
     (mêmes lettres sans diacritiques).
   - Les lemmes viennent du modèle : aucun dictionnaire de réponses écrit à la main.
5. **Serveur MCP (bonus).** `serveur_mcp.py`, bibliothèque standard seulement : JSON-RPC 2.0 sur stdin/stdout,
   un message par ligne, journaux sur stderr uniquement. Méthodes `initialize` (renvoyer `protocolVersion`,
   `capabilities: {"tools": {}}`, `serverInfo`), `tools/list`, `tools/call`, `ping` ; ignorer les notifications.
   Outils `chercher` (`requete`, `contexte`, `texte`) et `frequences` (`texte`, `top`), réponses en texte,
   en réutilisant les paliers 1 et 2.

## Ce que tu dois faire

- Un palier à la fois, celui qu'on te demande. Lance son test, montre la sortie, corrige jusqu'à « réussi ».
- Quand un test échoue, lis le message et le test, puis corrige **le code**.
- Vérifie une API dans la doc ou le code installé plutôt que de la deviner.
- Demande avant d'installer quoi que ce soit ou de supprimer un fichier.

## Ce que tu ne dois pas faire

- Modifier `corpus/` ou `tests/`, affaiblir un test, ou écrire en dur les résultats attendus.
- Afficher la clé Aristote, ou la copier dans un fichier ou dans le code : elle ne sert que dans l'en-tête HTTP.
- `git push`, `git reset --hard`, `rm -rf` : jamais sans accord explicite.
- Mentionner l'outil ou le modèle dans les fichiers ou les commits.
