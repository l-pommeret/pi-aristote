# Vedettes du LSJ

`lsj_vedettes.txt` : 126 787 mots-vedettes du Liddell-Scott-Jones, un par ligne, triés, en UTF-8 NFC.

Forme des vedettes : accent aigu (jamais grave), sans macron ni brève, sans numéro d'homonyme.
Les noms propres gardent leur majuscule (`Ἀχιλλεύς`, `Σωκράτης`) : comparez sans tenir compte de la casse.

Un lemme proposé par un modèle qui n'est pas dans cette liste est suspect (accent faux, forme dialectale,
mot inventé) ; un lemme qui y est n'est pas forcément juste (`δ’` est une vedette du LSJ, mais le lemme
attendu de `δ’` est `δέ`).

Exemple en Python :

```python
vedettes = {v.lower() for v in open("corpus/lexique/lsj_vedettes.txt", encoding="utf-8").read().split()}
"ψυχή" in vedettes        # True
"ψυχὴ" in vedettes        # False : accent grave, normalisez d'abord
```

Provenance et licence : voir `../LICENCE.md`.
