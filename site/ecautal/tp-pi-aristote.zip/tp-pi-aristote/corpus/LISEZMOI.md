# Le corpus du TP

Neuf textes grecs (40 804 mots) autour d'un même fil : **l'âme, les morts et la défense devant les juges**.
Homère montre les ψυχαί des morts dans la Nékyia (Odyssée 11) ; Socrate, dans l'Apologie de Platon,
cite Achille (Iliade 18.98, « αὐτίκα τεθναίην ») et imagine retrouver aux Enfers Minos, Ajax et Agamemnon,
ceux qu'Ulysse y a vus ; Xénophon raconte le même procès ; Lysias plaide deux autres affaires de meurtre.

Ce sont les éditions que The Greek Library (https://thegreeklibrary.org) publie sous l'identifiant
`…local001` : le texte de la Perseus Digital Library, extrait des fichiers EpiDoc de `canonical-greekLit`
(révision `790c84289edbdbe289dd7b752bfea29f0af4299d`).

**Ce dossier est en lecture seule** : les tests vérifient qu'il n'a pas changé.

## Les textes

| Identifiant | Auteur | Œuvre | Extrait | Édition | Lignes | Mots |
|---|---|---|---|---|---:|---:|
| `homere-iliade-01` | Homère | Iliade | chant 1 (la colère d'Achille) | Monro et Allen, Oxford, 1908-1920 | 611 | 4 519 |
| `homere-iliade-18` | Homère | Iliade | chant 18 (le bouclier d'Achille) | Monro et Allen, Oxford, 1908-1920 | 617 | 4 420 |
| `homere-odyssee-11` | Homère | Odyssée | chant 11 (la Nékyia) | A. T. Murray, Loeb, 1919 | 640 | 4 533 |
| `platon-euthyphron` | Platon | Euthyphron | intégral | J. Burnet, Oxford, 1905 | 283 | 5 171 |
| `platon-apologie` | Platon | Apologie de Socrate | intégral | J. Burnet, Oxford, 1905 | 148 | 8 745 |
| `platon-criton` | Platon | Criton | intégral | J. Burnet, Oxford, 1905 | 150 | 4 166 |
| `xenophon-apologie` | Xénophon | Apologie de Socrate | intégral | E. C. Marchant, Oxford, 1921 | 34 | 2 000 |
| `lysias-01` | Lysias | Sur le meurtre d'Ératosthène | intégral | W. R. M. Lamb, Loeb, 1930 | 50 | 2 407 |
| `lysias-12` | Lysias | Contre Ératosthène | intégral | W. R. M. Lamb, Loeb, 1930 | 100 | 4 843 |

Toutes les métadonnées (URN CTS, identifiant et adresse dans The Greek Library, adresse Perseus,
édition, licence, empreinte SHA-256, nombre de mots) sont dans `metadonnees.json`.

## Les formats

- `textes/<identifiant>.txt` : **le texte brut**, en UTF-8 normalisé NFC, une ligne par segment,
  au format `référence<TAB>texte`. Plusieurs lignes peuvent porter la même référence (répliques d'un dialogue).
  - Homère : `chant.vers` (`1.1`, `18.98`) ;
  - Platon : page et section de Stephanus (`17a`, `28d`) ;
  - Lysias : `discours.section` (`1.1`, `12.4`) ; Xénophon : section (`1`).

  Les notes, les noms des interlocuteurs (ΣΩ., ΕΥΘ.), les titres et les passages que l'éditeur condamne
  (`<del>`) sont retirés ; les ajouts de l'éditeur (`<add>`) sont gardés ; une lacune devient `[…]`.
  Le texte garde l'apostrophe d'élision de Perseus, `ʼ` (U+02BC) : `δʼ`, `ἀλλʼ`.
  Seule correction : un caractère parasite « > » retiré en Ap. 18b.
- `tei/<identifiant>.xml` : **l'original** au format TEI EpiDoc de Perseus. Pour Homère, le fichier ne garde
  que le chant concerné (le reste de l'en-tête et du texte est inchangé, une ligne `<change>` le signale).
- `lexique/lsj_vedettes.txt` : les 126 787 vedettes du dictionnaire Liddell-Scott-Jones, une par ligne
  (voir `lexique/LISEZMOI.md`), pour vérifier des lemmes au palier 4.

## Licence

Textes : CC BY-SA 4.0, Perseus Digital Library. Voir `LICENCE.md` : si vous publiez quelque chose qui
contient ces textes (la page web du palier 3, par exemple), citez la source et gardez la même licence.
