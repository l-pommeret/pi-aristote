# Licences et attributions

## Textes grecs (`textes/`, `tei/`)

Les transcriptions numériques viennent de la **Perseus Digital Library** (Tufts University), dépôt
`PerseusDL/canonical-greekLit`, révision `790c84289edbdbe289dd7b752bfea29f0af4299d`, diffusé sous
**Creative Commons Attribution - Partage dans les mêmes conditions 4.0 International (CC BY-SA 4.0)** :
https://creativecommons.org/licenses/by-sa/4.0/deed.fr

Les éditions imprimées sous-jacentes sont toutes antérieures à 1931 :

- Homère, *Iliade* : D. B. Monro et T. W. Allen, *Homeri Opera*, t. I-II, Oxford, Clarendon Press, 3e éd., 1908-1920.
- Homère, *Odyssée* : A. T. Murray, *The Odyssey*, Londres, Heinemann, et New York, Putnam, 1919 (Loeb).
- Platon, *Euthyphron*, *Apologie*, *Criton* : J. Burnet, *Platonis Opera*, t. I, Oxford, Clarendon Press, 1905.
- Xénophon, *Apologie de Socrate* : E. C. Marchant, *Xenophontis opera omnia*, t. II, Oxford, Clarendon Press, 1921.
- Lysias, discours 1 et 12 : W. R. M. Lamb, *Lysias*, Cambridge (Mass.), Harvard University Press, et Londres, Heinemann, 1930 (Loeb).

Modifications apportées pour le TP (22 octobre 2026) : extraction du texte brut (`textes/`), découpage
d'Homère au chant (`tei/homere-*.xml`), retrait d'un caractère parasite en Platon, Ap. 18b. Ces fichiers
dérivés sont diffusés sous la même licence CC BY-SA 4.0.

Attribution suggérée : « Texte grec : Perseus Digital Library (Tufts University), CC BY-SA 4.0, via
The Greek Library (thegreeklibrary.org). »

## Liste des vedettes du LSJ (`lexique/lsj_vedettes.txt`)

Vedettes du *Greek-English Lexicon* de Liddell, Scott et Jones (9e éd., 1940), d'après la version
numérique de la Perseus Digital Library (CC BY-SA 4.0) telle que la livre Eulexis (Philippe Verkerk,
https://github.com/PhVerkerk/Eulexis_off_line), complétée de quelques vedettes usuelles. Seule la liste
des mots-vedettes est reprise, sans les articles du dictionnaire. Diffusée sous CC BY-SA 4.0.
