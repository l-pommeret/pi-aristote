#!/usr/bin/env python3
"""Palier 5 (bonus) : un serveur MCP qui expose le corpus à pi.

    python3 tests/palier5.py
    python3 tests/palier5.py --commande "uv run --with fastmcp python serveur_mcp.py"

Le test parle MCP au serveur comme le ferait pi : JSON-RPC, un message par ligne sur stdin/stdout.
"""
from __future__ import annotations

import argparse
import json
import os
import queue
import shlex
import subprocess
import sys
import threading
import time

from commun import RACINE, Rapport, verifier_corpus

a = argparse.ArgumentParser()
a.add_argument("--commande", help="commande qui lance le serveur (par défaut : python3 serveur_mcp.py)")
args = a.parse_args()

r = Rapport("Palier 5 : serveur MCP")
verifier_corpus(r)
if not args.commande and not (RACINE / "serveur_mcp.py").exists():
    r.arreter("serveur_mcp.py existe", "Créez serveur_mcp.py (voir AGENTS.md, palier 5).")
commande = shlex.split(args.commande) if args.commande else [sys.executable, "serveur_mcp.py"]
env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
try:
    proc = subprocess.Popen(commande, cwd=RACINE, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env=env, text=True, encoding="utf-8", errors="replace", bufsize=1)
except OSError as e:
    r.arreter("le serveur démarre", str(e))

lignes: "queue.Queue[str]" = queue.Queue()
parasites: list[str] = []
erreurs: list[str] = []
threading.Thread(target=lambda: [lignes.put(l) for l in proc.stdout], daemon=True).start()
threading.Thread(target=lambda: [erreurs.append(l) for l in proc.stderr], daemon=True).start()


def envoyer(message: dict) -> None:
    proc.stdin.write(json.dumps(message, ensure_ascii=False) + "\n")
    proc.stdin.flush()


def attendre(ident: int, delai: float = 30) -> dict | None:
    fin = time.time() + delai
    while time.time() < fin:
        try:
            ligne = lignes.get(timeout=max(0.1, fin - time.time()))
        except queue.Empty:
            break
        try:
            message = json.loads(ligne)
        except ValueError:
            parasites.append(ligne.rstrip())
            continue
        if isinstance(message, dict) and message.get("id") == ident:
            return message
    return None


def arreter_serveur() -> None:
    try:
        proc.stdin.close()
        proc.wait(timeout=5)
    except Exception:
        proc.kill()


def journal() -> str:
    return ("stderr du serveur :\n" + "".join(erreurs[-15:])) if erreurs else ""


def appel(ident: int, outil: str, arguments: dict) -> str | None:
    envoyer({"jsonrpc": "2.0", "id": ident, "method": "tools/call", "params": {"name": outil, "arguments": arguments}})
    rep = attendre(ident, 60)
    if not rep or "result" not in rep:
        r.verifier(False, f"tools/call {outil} répond", f"réponse : {rep}\n{journal()}")
        return None
    res = rep["result"]
    texte = "\n".join(c.get("text", "") for c in res.get("content", []) if isinstance(c, dict))
    if res.get("isError"):
        r.verifier(False, f"tools/call {outil} sans erreur", texte[:500])
        return None
    return texte


try:
    envoyer({"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {
        "protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "test-palier5", "version": "1.0"}}})
    rep = attendre(1, 30)
    if not r.verifier(bool(rep) and "result" in rep and "protocolVersion" in rep["result"],
                      "initialize : le serveur répond avec sa version du protocole",
                      f"réponse : {rep}\n{journal()}"):
        arreter_serveur()
        r.fin()
    envoyer({"jsonrpc": "2.0", "method": "notifications/initialized"})
    envoyer({"jsonrpc": "2.0", "id": 2, "method": "tools/list"})
    rep = attendre(2, 30)
    outils = {t.get("name"): t for t in ((rep or {}).get("result") or {}).get("tools", []) if isinstance(t, dict)}
    r.verifier({"chercher", "frequences"} <= set(outils), "tools/list annonce les outils chercher et frequences",
               f"outils annoncés : {sorted(outils)}")
    r.verifier(all(isinstance(t.get("inputSchema"), dict) and t.get("description") for t in outils.values()) and bool(outils),
               "chaque outil a une description et un inputSchema (c'est ce que lit le modèle)")
    if "chercher" in outils:
        texte = appel(3, "chercher", {"requete": "τεθναίην"})
        if texte is not None:
            r.verifier("28d" in texte and "18.98" in texte, "chercher τεθναίην renvoie Il. 18.98 et Ap. 28d", texte[:400])
    if "frequences" in outils:
        texte = appel(4, "frequences", {"texte": "platon-apologie", "top": 3})
        if texte is not None:
            r.verifier("καί" in texte and "465" in texte, "frequences de l'Apologie : καί en tête (465)", texte[:400])
    r.verifier(not parasites, "stdout ne contient que du JSON-RPC (les print de débogage vont sur stderr)",
               "lignes parasites : " + " | ".join(parasites[:3]))
    r.bonus("textes" in outils, "un outil textes qui liste le corpus")
finally:
    arreter_serveur()
r.info('pour pi : pi mcp add corpus --exposure direct -- python3 "$PWD/serveur_mcp.py", puis pi mcp list')
r.fin()
