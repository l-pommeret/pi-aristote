#!/usr/bin/env python3
"""Palier 4 : lemmatiser avec l'API Aristote, en vérifiant chaque lemme dans le LSJ.

    python3 lemmatiser.py tests/donnees/palier4.txt > sorties/palier4.tsv
    python3 tests/palier4.py

Le test n'appelle pas l'API : il lit sorties/palier4.tsv et cache/aristote.jsonl.
Les lemmes attendus sont chiffrés dans tests/donnees/palier4_gold.json.
"""
from __future__ import annotations

import hashlib
import json
import re
import unicodedata

from commun import CORPUS, RACINE, Rapport, ref_normaliser, verifier_corpus

SEUIL = 0.70
r = Rapport("Palier 4 : lemmatisation")
verifier_corpus(r)
GOLD = json.loads((RACINE / "tests" / "donnees" / "palier4_gold.json").read_text(encoding="utf-8"))
SEL = GOLD["sel"]
_APOS = str.maketrans({c: "\u2019" for c in "'\u02bc\u1fbd\u1fbf\u0384\u00b4"})


def canon(lemme: str) -> str:
    d = unicodedata.normalize("NFD", re.sub(r"\d+$", "", lemme.strip()))
    d = d.replace("\u0304", "").replace("\u0306", "").replace("\u0300", "\u0301")
    return unicodedata.normalize("NFC", d).lower().translate(_APOS)


def nu(lemme: str) -> str:
    d = unicodedata.normalize("NFD", canon(lemme))
    return re.sub(r"σ$", "ς", "".join(c for c in d if not unicodedata.combining(c)))


def h(s: str) -> str:
    return hashlib.sha256((SEL + s).encode("utf-8")).hexdigest()[:20]


if not (RACINE / "lemmatiser.py").exists():
    r.arreter("lemmatiser.py existe", "Créez lemmatiser.py (voir AGENTS.md, palier 4).")
SORTIE = RACINE / "sorties" / "palier4.tsv"
if not SORTIE.exists():
    r.arreter("sorties/palier4.tsv existe",
              "Lancez d'abord : python3 lemmatiser.py tests/donnees/palier4.txt > sorties/palier4.tsv\n"
              "(mkdir sorties si besoin ; comptez une à quelques minutes selon le modèle)")

lignes = [l.rstrip("\r\n").split("\t") for l in SORTIE.read_text(encoding="utf-8", errors="replace").splitlines() if l.strip()]
if lignes and lignes[0][0].strip().lower() == "forme":
    lignes = lignes[1:]
attendu = [(p["source"], f, lem, nus) for p in GOLD["phrases"]
           for f, lem, nus in zip(p["formes"], p["lemmes"], p["lemmes_sans_accents"])]

r.verifier(all(len(l) >= 3 for l in lignes), "chaque ligne a trois colonnes : forme, lemme, lsj",
           f"première ligne fautive : {next((l for l in lignes if len(l) < 3), None)}")
if not r.verifier(len(lignes) == len(attendu), f"une ligne par mot ({len(attendu)} mots dans tests/donnees/palier4.txt)",
                  f"obtenu : {len(lignes)} lignes. La ponctuation n'est pas un mot ; δ\u2019 en est un."):
    r.fin()
decalage = next((i for i, (l, a) in enumerate(zip(lignes, attendu)) if ref_normaliser(l[0]) != ref_normaliser(a[1])), None)
if not r.verifier(decalage is None, "les formes sont celles du texte, dans l'ordre",
                  decalage is not None and f"ligne {decalage + 1} : attendu {attendu[decalage][1]!r}, obtenu {lignes[decalage][0]!r}"):
    r.fin()

# Exactitude, par phrase et au total.
justes, presque, par_phrase = 0, 0, {}
for l, (source, forme, lem, nus) in zip(lignes, attendu):
    lemme = l[1].strip() if len(l) > 1 else ""
    ok = h(canon(lemme)) in lem
    justes += ok
    presque += ok or h(nu(lemme)) in nus
    n, j = par_phrase.get(source, (0, 0))
    par_phrase[source] = (n + 1, j + ok)
for source, (n, j) in par_phrase.items():
    r.info(f"{source:16} {j:3}/{n} lemmes justes")
taux = justes / len(attendu)
r.info(f"à l'accent près : {presque}/{len(attendu)}")
r.verifier(taux >= SEUIL, f"au moins {SEUIL:.0%} de lemmes justes (obtenu : {justes}/{len(attendu)} = {taux:.0%})",
           "Améliorez le prompt (conventions du LSJ, exemples), changez de modèle, ou relancez sur les lemmes absents du LSJ.")

# La colonne lsj dit vrai.
vedettes = {canon(v) for v in (CORPUS / "lexique" / "lsj_vedettes.txt").read_text(encoding="utf-8").split()}
faux = [l for l in lignes if len(l) >= 3 and (canon(l[1]) in vedettes) != (l[2].strip().lower() in ("oui", "o", "1", "true", "vrai"))]
r.verifier(not faux, "la colonne lsj (oui/non) correspond au lexique corpus/lexique/lsj_vedettes.txt",
           f"{len(faux)} ligne(s) fausse(s), par exemple {faux[:3]}")
oui = sum(1 for l in lignes if len(l) >= 3 and canon(l[1]) in vedettes)
r.info(f"{oui}/{len(lignes)} lemmes sont des vedettes du LSJ")

# Les lemmes viennent bien du modèle : réponses brutes gardées dans cache/aristote.jsonl.
CACHE = RACINE / "cache" / "aristote.jsonl"
entrees = []
if CACHE.exists():
    for l in CACHE.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            e = json.loads(l)
            if isinstance(e, dict):
                entrees.append(e)
        except ValueError:
            pass
r.verifier(bool(entrees) and all("modele" in e and "reponse" in e for e in entrees),
           "cache/aristote.jsonl garde les réponses brutes du modèle (champs modele et reponse)",
           "Une ligne JSON par appel : {\"modele\": …, \"messages\": …, \"reponse\": …} ; elle sert aussi de cache.")
if entrees:
    brut = unicodedata.normalize("NFC", "\n".join(str(e.get("reponse", "")) for e in entrees)).translate(_APOS)
    absents = [l[1] for l in lignes if len(l) > 1 and l[1].strip() and canon(l[1]) not in canon(brut)]
    r.verifier(len(absents) <= len(lignes) // 10, "les lemmes de la sortie se trouvent dans les réponses du modèle",
               f"{len(absents)} lemmes introuvables dans le cache, par exemple {absents[:5]} : sont-ils codés en dur ?")
    r.info("modèle(s) utilisé(s) : " + ", ".join(sorted({str(e.get('modele')) for e in entrees})))

# Aucune clé dans le projet.
CLE = re.compile(r"sk-[A-Za-z0-9_\-]{16,}")
fuites = []
for f in RACINE.rglob("*"):
    if f.is_file() and not any(p in f.parts for p in (".git", "corpus", "tests", "node_modules", "__pycache__")) \
            and f.stat().st_size < 5_000_000:
        try:
            if CLE.search(f.read_text(encoding="utf-8", errors="ignore")):
                fuites.append(str(f.relative_to(RACINE)))
        except OSError:
            pass
r.verifier(not fuites, "aucune clé sk-… écrite dans les fichiers du projet",
           "Clé trouvée dans : " + ", ".join(fuites) + "\nRetirez-la, et régénérez-en une sur https://aristote.education/llm-access/")
r.fin()
