#!/usr/bin/env python3
"""Palier 3 : une page web statique pour chercher dans le corpus.

    python3 tests/palier3.py

La recherche (site/recherche.js) est exécutée dans Node, comme dans un navigateur :
donnees.js puis recherche.js sont chargés comme deux balises <script> classiques.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
import unicodedata
from pathlib import Path

from commun import RACINE, Rapport, executer, python, ref_mots, verifier_corpus

r = Rapport("Palier 3 : page web")
verifier_corpus(r)
SITE = RACINE / "site"

if not (RACINE / "construire_site.py").exists():
    r.arreter("construire_site.py existe", "Créez construire_site.py : il écrit site/donnees.js à partir de corpus/.")
try:
    p = python("construire_site.py", delai=120)
except subprocess.TimeoutExpired:
    r.arreter("python3 construire_site.py se termine", "Plus de 2 minutes : quelque chose tourne en rond.")
if not r.verifier(p.returncode == 0, "python3 construire_site.py fonctionne", p.stderr[-800:]):
    r.fin()

for nom in ("index.html", "donnees.js", "recherche.js"):
    if not (SITE / nom).exists():
        r.arreter(f"site/{nom} existe", f"Il manque site/{nom} (voir AGENTS.md, palier 3).")

html = (SITE / "index.html").read_text(encoding="utf-8", errors="replace")
scripts = re.findall(r"<script\b([^>]*)>", html, flags=re.I)
sources = [re.search(r"""src\s*=\s*["']?([^"' >]+)""", s, flags=re.I) for s in scripts]
sources = [m.group(1) for m in sources if m]
r.verifier("donnees.js" in sources and "recherche.js" in sources
           and sources.index("donnees.js") < sources.index("recherche.js"),
           "index.html charge donnees.js puis recherche.js",
           f'Attendu : <script src="donnees.js"></script> puis <script src="recherche.js"></script> ; trouvé : {sources}')
r.verifier(not any("module" in s.lower() for s in scripts),
           "pas de <script type=\"module\"> (bloqué quand on ouvre la page en double-cliquant, en file://)")
r.verifier(bool(re.search(r"<input\b", html, flags=re.I)), "index.html contient un champ de recherche <input>")
if re.search(r"\bfetch\s*\(", html + (SITE / "recherche.js").read_text(encoding="utf-8", errors="replace")):
    r.info("fetch() repéré : il échoue en file:// ; les données doivent venir de donnees.js.")
if re.search(r"""(src|href)\s*=\s*["']https?://""", html, flags=re.I):
    r.info("ressource externe (http…) : la page doit marcher sans réseau.")

node = shutil.which("node")
if not node:
    r.arreter("Node.js est disponible", "pi en a besoin : lancez ce test dans le même terminal que pi.")

HARNAIS = r"""
const fs = require("fs"), vm = require("vm"), path = require("path");
const dossier = process.argv[2], requetes = JSON.parse(fs.readFileSync(process.argv[3], "utf8"));
const ctx = vm.createContext({ console });
ctx.window = ctx; ctx.self = ctx;
const sortie = {};
try {
  for (const f of ["donnees.js", "recherche.js"])
    vm.runInContext(fs.readFileSync(path.join(dossier, f), "utf8"), ctx, { filename: f, timeout: 20000 });
} catch (e) { sortie.erreur = "chargement : " + String(e && e.stack || e).split("\n").slice(0, 4).join("\n"); }
if (!sortie.erreur) {
  ctx.__requetes = requetes;
  const code = `(function () {
    const C = typeof CORPUS !== "undefined" ? CORPUS : window.CORPUS;
    if (C === undefined) return { erreur: "CORPUS n'est pas défini par donnees.js" };
    if (typeof chercher !== "function") return { erreur: "recherche.js ne définit pas la fonction chercher(corpus, requete, options)" };
    const res = {};
    for (const [cle, q, o] of __requetes) {
      try { const r = chercher(C, q, o); res[cle] = Array.isArray(r) ? r.map(x => ({ texte: x.texte, ref: String(x.ref), gauche: x.gauche, mot: x.mot, droite: x.droite })) : { erreur: "chercher() doit renvoyer un tableau" }; }
      catch (e) { res[cle] = { erreur: String(e && e.stack || e).split("\\n").slice(0, 3).join("\\n") }; }
    }
    return res;
  })()`;
  try { Object.assign(sortie, vm.runInContext(code, ctx, { timeout: 60000 })); }
  catch (e) { sortie.erreur = String(e); }
}
process.stdout.write(JSON.stringify(sortie));
"""

REQUETES = [
    ["tethnaien", "τεθναίην", {}],
    ["contexte", "τεθναίην", {"contexte": 3}],
    ["prefixe", "ψυχ*", {}],
    ["prefixe_sigma", "Ὀδυσσ*", {}],
    ["nfd", unicodedata.normalize("NFD", "ψυχὴ"), {}],
    ["apostrophe", "δ'", {}],
    ["sans_accents", "ψυχη", {"sansAccents": True}],
]

with tempfile.TemporaryDirectory() as tmp:
    (Path(tmp) / "harnais.js").write_text(HARNAIS, encoding="utf-8")
    (Path(tmp) / "requetes.json").write_text(json.dumps(REQUETES, ensure_ascii=False), encoding="utf-8")
    try:
        p = executer([node, str(Path(tmp) / "harnais.js"), str(SITE), str(Path(tmp) / "requetes.json")], delai=120)
    except subprocess.TimeoutExpired:
        r.arreter("la recherche JavaScript répond", "Plus de 2 minutes dans Node.")
try:
    res = json.loads(p.stdout)
except ValueError:
    r.arreter("le harnais Node s'exécute", (p.stderr or p.stdout)[-800:])
if "erreur" in res:
    r.arreter("donnees.js et recherche.js se chargent comme dans un navigateur", res["erreur"] +
              "\n(recherche.js ne doit définir que des fonctions : pas d'accès au DOM au chargement)")


def resultat(cle: str, message: str):
    x = res.get(cle)
    if not isinstance(x, list):
        r.verifier(False, message, (x or {}).get("erreur", "pas de résultat") if isinstance(x, dict) else "pas de résultat")
        return None
    return x


x = resultat("tethnaien", "chercher(CORPUS, 'τεθναίην')")
if x is not None:
    lieux = sorted((h["texte"], h["ref"]) for h in x)
    r.verifier(lieux == [("homere-iliade-18", "18.98"), ("platon-apologie", "28d")],
               "chercher(CORPUS, 'τεθναίην') : Il. 18.98 et Ap. 28d (champs texte et ref)",
               f"obtenu : {lieux}")
x = resultat("contexte", "chercher(CORPUS, 'τεθναίην', {contexte: 3})")
if x is not None:
    ap = next((h for h in x if h["ref"] == "28d"), None)
    r.verifier(bool(ap) and ref_mots(ap["gauche"] or "") == ["τιμωρεῖν", "αὐτίκα", "φησί"],
               "option contexte : trois mots à gauche (Ap. 28d)", f"obtenu : {ap and ap['gauche']!r}")
x = resultat("prefixe", "chercher(CORPUS, 'ψυχ*')")
if x is not None:
    r.verifier(len(x) == 28, "ψυχ* : 28 occurrences, comme en Python", f"obtenu : {len(x)}")
x = resultat("prefixe_sigma", "chercher(CORPUS, 'Ὀδυσσ*')")
if x is not None:
    r.verifier(len(x) == 16, "Ὀδυσσ* : 16 occurrences (un préfixe ne prend pas de sigma final)", f"obtenu : {len(x)}")
x = resultat("nfd", "requête en NFD")
if x is not None:
    r.verifier(len(x) == 11, "une requête décomposée (NFD) et à l'accent grave trouve ψυχή (11 fois)",
               f"obtenu : {len(x)} (pensez à String.prototype.normalize)")
x = resultat("apostrophe", "requête δ'")
if x is not None:
    r.verifier(len(x) == 554, "l'apostrophe du clavier trouve les δ\u2019 du corpus (554)", f"obtenu : {len(x)}")
x = res.get("sans_accents")
r.bonus(isinstance(x, list) and len(x) == 13, "option {sansAccents: true} (ψυχη : 13)")
r.info("ouvrez site/index.html dans un navigateur (double-clic) ou demandez à pi de la regarder avec son navigateur.")
r.fin()
