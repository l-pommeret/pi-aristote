#!/usr/bin/env python3
"""Palier 1 : lire le corpus, normaliser le grec, compter les mots.

    python3 tests/palier1.py
"""
from __future__ import annotations

import subprocess
import unicodedata
from pathlib import Path

from commun import Rapport, appeler, importer, montrer, python, ref_normaliser, verifier_corpus

r = Rapport("Palier 1 : fréquences")
verifier_corpus(r)
mots = importer(r, "grec", "mots")

NFD = lambda s: unicodedata.normalize("NFD", s)  # noqa: E731

CAS = [
    ("des mots simples, accents gardés", "μῆνιν ἄειδε θεὰ Πηληϊάδεω Ἀχιλῆος",
     ["μῆνιν", "ἄειδε", "θεά", "πηληϊάδεω", "ἀχιλῆος"]),
    ("une entrée décomposée (NFD) donne des mots composés (NFC)", NFD("θεὰ καὶ ψυχῇ"), ["θεά", "καί", "ψυχῇ"]),
    ("l'accent grave devient aigu", "καὶ δὲ τὸν", ["καί", "δέ", "τόν"]),
    ("la ponctuation est retirée", "ἔθηκε, μάχεσθαι; υἱός· λέγειν—πιστεύω (οὐ γὰρ ᾔδη).",
     ["ἔθηκε", "μάχεσθαι", "υἱός", "λέγειν", "πιστεύω", "οὐ", "γάρ", "ᾔδη"]),
    ("point d'interrogation grec (U+037E) et ano teleia (U+0387)", "τί φῄς\u037e γραφὴν\u0387 ἀλλὰ",
     ["τί", "φῄς", "γραφήν", "ἀλλά"]),
    ("toutes les apostrophes d'élision deviennent \u2019 (U+2019)", "δ\u02bc δ\u2019 δ' δ\u1fbd ἀλλ\u02bc", ["δ\u2019", "δ\u2019", "δ\u2019", "δ\u2019", "ἀλλ\u2019"]),
    ("un mot élidé collé au suivant est coupé", "δ\u2019ἔθηκε ἀλλ\u02bcἐγώ", ["δ\u2019", "ἔθηκε", "ἀλλ\u2019", "ἐγώ"]),
    ("majuscules et sigma final", "ΣΩΚΡΑΤΗΣ Σωκράτης λόγοσ", ["σωκρατης", "σωκράτης", "λόγος"]),
    ("tonos et oxia sont confondus (ί U+1F77 = ί U+03AF)", "κα\u1f77 κα\u03af", ["καί", "καί"]),
    ("les crochets éditoriaux ne font pas des mots", "[ὡς] ⟨τὸν⟩ […]", ["ὡς", "τόν"]),
]

for nom, entree, attendu in CAS:
    obtenu, ok = appeler(r, nom, mots, entree)
    if not ok:
        continue
    obtenu = list(obtenu) if obtenu is not None else None
    r.verifier(obtenu == attendu, nom,
               f"mots({montrer(entree)})\n  attendu : {montrer(attendu)}\n  obtenu  : {montrer(obtenu)}")


def lire_frequences(args: list[str], message: str) -> list[tuple[str, int]] | None:
    try:
        p = python("frequences.py", *args)
    except subprocess.TimeoutExpired:
        r.verifier(False, message, "frequences.py a mis plus de 60 s : le corpus ne fait que 41 000 mots.")
        return None
    if p.returncode != 0:
        r.verifier(False, message, f"python3 frequences.py {' '.join(args)} a échoué :\n{p.stderr[-800:]}")
        return None
    lignes = []
    for ligne in p.stdout.splitlines():
        champs = ligne.split()
        if len(champs) == 2 and champs[1].isdigit():
            lignes.append((champs[0], int(champs[1])))
    return lignes


def comparer(args: list[str], attendu: list[tuple[str, int]], message: str, sans_accents: bool = False) -> bool:
    lignes = lire_frequences(args, message)
    if lignes is None:
        return False
    obtenu = [(ref_normaliser(m, sans_accents), n) for m, n in lignes[: len(attendu)]]
    ok = obtenu == attendu
    r.verifier(ok, message,
               f"python3 frequences.py {' '.join(args)}\n  attendu : {attendu}\n  obtenu  : {lignes[: len(attendu)]}"
               "\n  (format : une ligne « mot<TAB>compte » par mot, du plus fréquent au moins fréquent)")
    return ok


if r.verifier(Path("frequences.py").exists(), "frequences.py existe", "Créez frequences.py à la racine du projet."):
    comparer(["--top", "10"], [("καί", 1714), ("δέ", 795), ("δ\u2019", 554), ("μέν", 493), ("γάρ", 439), ("τε", 363),
                               ("τῶν", 348), ("ἄν", 334), ("ἤ", 314), ("ὦ", 308)],
             "les 10 mots les plus fréquents du corpus")
    comparer(["--texte", "platon-apologie", "--top", "6"],
             [("καί", 465), ("δέ", 142), ("γάρ", 125), ("ἄν", 115), ("μέν", 106), ("ὦ", 105)],
             "les 6 mots les plus fréquents de l'Apologie de Platon (--texte platon-apologie)")
    comparer(["--texte", "homere-odyssee-11", "--top", "3"], [("καί", 119), ("δ\u2019", 105), ("δέ", 95)],
             "les 3 mots les plus fréquents du chant 11 de l'Odyssée")
    p = python("frequences.py", "--sans-accents", "--top", "4")
    bonus = p.returncode == 0 and [(ref_normaliser(c[0], True), c[1]) for c in
                                   (l.split() for l in p.stdout.splitlines()) if len(c) == 2][:4] == \
        [("και", "1714"), ("δε", "795"), ("δ\u2019", "554"), ("η", "540")]
    r.bonus(bonus, "option --sans-accents (καί, δέ, δ\u2019, puis η qui fusionne ἤ, ἡ, ἦ, ἥ…)")

r.fin()
