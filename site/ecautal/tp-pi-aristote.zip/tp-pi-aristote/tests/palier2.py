#!/usr/bin/env python3
"""Palier 2 : un concordancier KWIC (mot-clé en contexte).

    python3 tests/palier2.py
"""
from __future__ import annotations

import subprocess
import unicodedata

from commun import Rapport, appeler, importer, montrer, python, ref_mots, ref_normaliser, verifier_corpus

r = Rapport("Palier 2 : concordance")
verifier_corpus(r)
concordance = importer(r, "concordance", "concordance")
CLES = {"texte", "ref", "gauche", "mot", "droite"}


def chercher(message: str, *args, **kwargs):
    res, ok = appeler(r, message, concordance, *args, **kwargs)
    if not ok:
        return None
    try:
        res = list(res)
    except TypeError:
        r.verifier(False, message, f"concordance() doit renvoyer une liste, pas {type(res).__name__}")
        return None
    mauvais = [x for x in res if not isinstance(x, dict) or not CLES <= set(x)]
    if mauvais:
        r.verifier(False, message, f"chaque résultat doit être un dict avec les clés {sorted(CLES)} ; reçu : {mauvais[0]!r}"[:400])
        return None
    return res


# 1. Le vers d'Achille que cite Socrate : Il. 18.98 et Ap. 28d.
res = chercher("concordance('τεθναίην') renvoie une liste de résultats", "τεθναίην")
if res is not None:
    lieux = sorted((x["texte"], str(x["ref"])) for x in res)
    r.verifier(lieux == [("homere-iliade-18", "18.98"), ("platon-apologie", "28d")],
               "τεθναίην : Achille (Il. 18.98) et Socrate qui le cite (Ap. 28d)",
               f"attendu : [('homere-iliade-18', '18.98'), ('platon-apologie', '28d')]\nobtenu  : {lieux}")
    r.verifier(all(ref_normaliser(x["mot"]) == "τεθναίην" for x in res), "le champ « mot » contient la forme trouvée",
               f"obtenu : {[x['mot'] for x in res]}")

# 2. Le contexte : n mots de chaque côté, sans ponctuation, et à cheval sur les vers.
res = chercher("concordance('τεθναίην', contexte=3)", "τεθναίην", contexte=3)
if res is not None:
    par_lieu = {str(x["ref"]): x for x in res}
    ap, il = par_lieu.get("28d"), par_lieu.get("18.98")
    r.verifier(bool(ap) and ref_mots(ap["gauche"]) == ["τιμωρεῖν", "αὐτίκα", "φησί"]
               and ref_mots(ap["droite"]) == ["δίκην", "ἐπιθείς", "τῷ"],
               "contexte=3 : trois mots à gauche et à droite (Ap. 28d)",
               "attendu : gauche « τιμωρεῖν αὐτίκα φησί », droite « δίκην ἐπιθεὶς τῷ »\n"
               f"obtenu  : {ap and (ap['gauche'], ap['droite'])}")
    r.verifier(bool(il) and ref_mots(il["gauche"]) == ["ὠκύς", "ἀχιλλεύς", "αὐτίκα"],
               "le contexte continue sur le vers précédent (Il. 18.97-98)",
               "attendu : gauche « ὠκὺς Ἀχιλλεύς αὐτίκα » (fin du vers 97, début du vers 98)\n"
               f"obtenu  : {il and il['gauche']!r}")

# 3. Préfixe : ψυχ* trouve toutes les formes de ψυχή.
res = chercher("concordance('ψυχ*')", "ψυχ*")
if res is not None:
    textes = sorted({x["texte"] for x in res})
    r.verifier(len(res) == 28, "ψυχ* : 28 occurrences (dont 19 dans la Nékyia)", f"obtenu : {len(res)} occurrences")
    r.verifier(textes == ["homere-iliade-01", "homere-odyssee-11", "lysias-01", "platon-apologie", "xenophon-apologie"],
               "ψυχ* : présent dans 5 textes", f"obtenu : {textes}")

res = chercher("concordance('Ὀδυσσ*')", "Ὀδυσσ*")
if res is not None:
    lieux = {(x["texte"], str(x["ref"])) for x in res}
    r.verifier(len(res) == 16 and ("platon-apologie", "41c") in lieux,
               "Ὀδυσσ* : 16 occurrences, dont Ap. 41c (un préfixe ne prend pas de sigma final)",
               f"obtenu : {len(res)} occurrences. Le préfixe « ὀδυσσ » ne doit pas devenir « ὀδυσς ».")

# 4. La requête est normalisée comme le texte.
nfd = unicodedata.normalize("NFD", "ψυχὴ")
res = chercher("concordance(requête en NFD)", nfd)
if res is not None:
    r.verifier(len(res) == 11, "une requête décomposée (NFD) et à l'accent grave trouve ψυχή (11 fois)",
               f"requête {montrer(nfd)} : {len(res)} occurrences au lieu de 11")
res = chercher("concordance(\"δ'\")", "δ'")
if res is not None:
    r.verifier(len(res) == 554, "une apostrophe tapée au clavier (') trouve les δ\u2019 du corpus (554)",
               f"obtenu : {len(res)} occurrences (le corpus écrit δ\u02bc avec U+02BC)")
res = chercher("concordance('Μίνως')", "Μίνως")
if res is not None:
    r.verifier([str(x["ref"]) for x in res] == ["41a"],
               "Μίνως (forme exacte) : seulement Ap. 41a ; Od. 11.568 a « Μίνωα » (il faudra des lemmes, palier 4)",
               f"obtenu : {[(x['texte'], x['ref']) for x in res]}")

# 5. En ligne de commande.
try:
    p = python("concordance.py", "τεθναίην")
    r.verifier(p.returncode == 0 and "28d" in p.stdout and "18.98" in p.stdout,
               "python3 concordance.py τεθναίην affiche les références",
               (p.stderr[-600:] or p.stdout[-600:]) if p.returncode or "28d" not in p.stdout else "")
except subprocess.TimeoutExpired:
    r.verifier(False, "python3 concordance.py τεθναίην répond en moins de 60 s")

try:
    bonus = len(list(concordance("ψυχη", sans_accents=True))) == 13
except Exception:
    bonus = False
r.bonus(bonus, "option sans_accents=True (ψυχη trouve ψυχή, ψυχὴ, ψυχῇ : 13)")
r.fin()
