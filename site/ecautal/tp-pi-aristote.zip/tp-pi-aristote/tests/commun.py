"""Outils partagés par les tests des paliers (bibliothèque standard uniquement).

Ne modifiez pas ce dossier : les tests sont la définition de « c'est fini ».
"""
from __future__ import annotations

import hashlib
import importlib
import json
import os
import re
import subprocess
import sys
import traceback
import unicodedata
from pathlib import Path

RACINE = Path(__file__).resolve().parent.parent
CORPUS = RACINE / "corpus"
sys.path.insert(0, str(RACINE))
os.chdir(RACINE)

for flux in (sys.stdout, sys.stderr):
    try:
        flux.reconfigure(encoding="utf-8")
    except (AttributeError, ValueError):
        pass

# --- Normalisation de référence (celle que décrit AGENTS.md) --------------
# Les tests s'en servent pour comparer avec tolérance ; votre code doit avoir la sienne.

_APOS = str.maketrans({c: "\u2019" for c in "'\u02bc\u1fbd\u1fbf\u0384\u00b4"})
_MOT = re.compile(r"(?:[^\W\d_]|[\u0300-\u036f])+\u2019?")


def ref_normaliser(mot: str, sans_accents: bool = False) -> str:
    d = unicodedata.normalize("NFD", unicodedata.normalize("NFC", str(mot).strip()).translate(_APOS))
    d = "".join(c for c in d if not unicodedata.combining(c)) if sans_accents else d.replace("\u0300", "\u0301")
    return re.sub(r"σ$", "ς", unicodedata.normalize("NFC", d).lower())


def ref_mots(texte: str) -> list[str]:
    return [ref_normaliser(m) for m in _MOT.findall(unicodedata.normalize("NFC", str(texte)).translate(_APOS))]


def montrer(valeur) -> str:
    """Affiche une valeur avec les points de code des caractères ambigus (apostrophes, accents)."""
    s = repr(valeur)
    suspects = {c for c in str(valeur) if ord(c) > 127 and (unicodedata.combining(c) or unicodedata.category(c)[0] in "PSZ"
                                                           or c in "\u02bc\u1fbd\u1fbf\u0384"
                                                           or unicodedata.normalize("NFC", c) != c)}
    if suspects:
        s += "  [" + ", ".join(f"U+{ord(c):04X} {unicodedata.name(c, '?')}" for c in sorted(suspects)) + "]"
    return s


# --- Rapport -------------------------------------------------------------

class Rapport:
    def __init__(self, titre: str):
        self.titre = titre
        self.ok = 0
        self.echecs = 0
        print(f"=== {titre} ===")

    def verifier(self, condition: bool, message: str, aide: str = "") -> bool:
        if condition:
            self.ok += 1
            print(f"  [OK]     {message}")
        else:
            self.echecs += 1
            print(f"  [ÉCHEC]  {message}")
            if aide:
                for ligne in aide.splitlines():
                    print(f"           {ligne}")
        return bool(condition)

    def bonus(self, condition: bool, message: str) -> None:
        print(f"  [BONUS]  {message} : {'oui' if condition else 'pas encore'}")

    def info(self, message: str) -> None:
        print(f"  [INFO]   {message}")

    def arreter(self, message: str, aide: str = "") -> None:
        self.verifier(False, message, aide)
        self.fin()

    def fin(self) -> None:
        total = self.ok + self.echecs
        if self.echecs:
            print(f"--- {self.titre} : {self.ok}/{total} vérifications réussies. À vous (et à l'agent) de jouer.")
            sys.exit(1)
        print(f"--- {self.titre} : réussi ({total}/{total}).")
        sys.exit(0)


def verifier_corpus(r: Rapport) -> list[dict]:
    """Le corpus doit être celui du kit : sinon les comptes attendus n'ont plus de sens."""
    try:
        textes = json.loads((CORPUS / "metadonnees.json").read_text(encoding="utf-8"))["textes"]
    except (OSError, ValueError, KeyError):
        r.arreter("corpus/metadonnees.json est lisible", "Le corpus du kit est absent ou abîmé : récupérez-le à nouveau.")
    abimes = []
    for t in textes:
        try:
            if hashlib.sha256((CORPUS / t["fichier"]).read_bytes()).hexdigest() != t["sha256"]:
                abimes.append(t["fichier"])
        except OSError:
            abimes.append(t["fichier"])
    if abimes:
        r.arreter("le corpus n'a pas été modifié",
                  "Fichiers modifiés ou absents : " + ", ".join(abimes) +
                  "\nLe corpus est en lecture seule : restaurez-le (git checkout corpus/, ou reprenez le kit).")
    return textes


def importer(r: Rapport, module: str, fonction: str):
    """Importe la fonction d'un module de l'étudiant, avec un message clair en cas d'échec."""
    if not (RACINE / f"{module}.py").exists():
        r.arreter(f"{module}.py existe", f"Le fichier {module}.py n'existe pas encore à la racine du projet.")
    try:
        sys.modules.pop(module, None)
        mod = importlib.import_module(module)
    except Exception:
        r.arreter(f"{module}.py s'importe sans erreur", traceback.format_exc(limit=3))
    if not callable(getattr(mod, fonction, None)):
        r.arreter(f"{module}.py définit la fonction {fonction}()", f"Aucune fonction {fonction} dans {module}.py (voir AGENTS.md).")
    return getattr(mod, fonction)


def appeler(r: Rapport, message: str, f, *args, **kwargs):
    """Appelle une fonction de l'étudiant ; une exception devient un échec lisible."""
    try:
        return f(*args, **kwargs), True
    except Exception:
        r.verifier(False, message, traceback.format_exc(limit=3))
        return None, False


def executer(args: list[str], delai: int = 60, entree: str | None = None) -> subprocess.CompletedProcess:
    env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
    return subprocess.run(args, cwd=RACINE, capture_output=True, text=True, encoding="utf-8", errors="replace",
                          timeout=delai, env=env, input=entree)


def python(script: str, *args: str, delai: int = 60) -> subprocess.CompletedProcess:
    return executer([sys.executable, script, *args], delai=delai)
