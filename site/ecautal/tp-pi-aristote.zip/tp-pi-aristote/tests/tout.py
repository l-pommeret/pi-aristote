#!/usr/bin/env python3
"""Lance les tests de tous les paliers et affiche un bilan.

    python3 tests/tout.py        # bilan court
    python3 tests/tout.py -v     # avec le détail de chaque palier
"""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

ICI = Path(__file__).resolve().parent
PALIERS = [
    ("palier1.py", "fréquences"),
    ("palier2.py", "concordance"),
    ("palier3.py", "page web"),
    ("palier4.py", "lemmatisation (Aristote)"),
    ("palier5.py", "serveur MCP (bonus)"),
]
detail = "-v" in sys.argv
env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
try:
    sys.stdout.reconfigure(encoding="utf-8")
except (AttributeError, ValueError):
    pass
bilan = []
for i, (script, nom) in enumerate(PALIERS, 1):
    try:
        p = subprocess.run([sys.executable, str(ICI / script)], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=300, env=env)
        code, sortie = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired:
        code, sortie = 1, "plus de 5 minutes"
    if detail:
        print(sortie)
    derniere = [l for l in sortie.splitlines() if l.startswith("---")]
    bilan.append((i, nom, code == 0, derniere[-1][4:] if derniere else sortie.strip()[-200:]))
print("Bilan")
for i, nom, ok, resume in bilan:
    print(f"  Palier {i} - {nom:28} {'réussi' if ok else 'à faire'}")
print("Détail d'un palier : python3 tests/palier1.py (etc.)")
