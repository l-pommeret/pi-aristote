# TP pi-aristote : un outil de TAL pour le grec ancien

TP de 40 minutes, EcAuTAL 2026 (LISN, Université Paris-Saclay). Fiche, diapositives et kit :
https://thegreeklibrary.org/pi-aristote/ecautal/

Ici, c'est l'agent qui écrit le code : vous demandez à pi (branché sur Aristote) de construire un petit outil de
TAL pour le grec ancien, palier par palier, vous lui faites lancer les tests et vous relisez ce qu'il a écrit.
Chaque palier a un test qui dit s'il est fini. Le corpus réunit neuf textes : Homère (Iliade 1 et 18,
Odyssée 11), Platon (Euthyphron, Apologie, Criton), Xénophon (Apologie) et Lysias (discours 1 et 12).

## Prérequis

pi-aristote installé, avec votre clé Aristote (à récupérer sur https://aristote.education/llm-access/). Sous
macOS ou Linux :

```bash
curl -fsSL https://thegreeklibrary.org/pi-aristote/install.sh | sh
```

Sous Windows, dans PowerShell (la première fois, il faut d'abord lancer `wsl --install` dans un PowerShell
administrateur, puis redémarrer) :

```powershell
wsl bash -lc "curl -fsSL https://thegreeklibrary.org/pi-aristote/install.sh | sh"
```

Il faut aussi `python3` (3.8 ou plus) et `git`, et rien d'autre.

## Démarrer (3 minutes)

Dans le terminal où `pi` marche (sous Windows, dans WSL et pas dans PowerShell) :

```bash
curl -fsSLO https://thegreeklibrary.org/pi-aristote/ecautal/tp-pi-aristote.zip
python3 -m zipfile -e tp-pi-aristote.zip .     # ou : unzip tp-pi-aristote.zip
cd tp-pi-aristote
git init -q && git add -A && git -c user.name=moi -c user.email=moi@example.org commit -qm "kit de départ"
python3 tests/tout.py                           # tout est « à faire »
pi
```

Le `git commit` est facultatif, mais avec lui `git diff` montrera ensuite tout ce que l'agent a changé.

Dans pi, `/aristote` doit lister des modèles. Sinon, tapez `/aristote key sk-…` avec votre clé
(https://aristote.education/llm-access/).

## Les paliers

| Palier | Temps conseillé | Ce que vous obtenez | Test |
|---|---|---|---|
| 1 | 10 min | les mots les plus fréquents, avec un grec bien normalisé | `python3 tests/palier1.py` |
| 2 | 8 min | un concordancier : chaque occurrence d'un mot dans son contexte | `python3 tests/palier2.py` |
| 3 | 8 min | une page web qui cherche dans le corpus, sans serveur | `python3 tests/palier3.py` |
| 4 | 10 min | des lemmes donnés par un LLM d'Aristote et vérifiés dans le LSJ | `python3 tests/palier4.py` |
| 5 | bonus | un serveur MCP : pi interroge lui-même le corpus | `python3 tests/palier5.py` |

Allez aussi loin que possible (le palier 3 est déjà un bon résultat). Ce qui est attendu à chaque palier est
décrit dans `AGENTS.md`, que pi lit tout seul en démarrant.

### Palier 1 : Fréquences

> Lis AGENTS.md. Fais le palier 1 : écris grec.py et frequences.py, puis lance python3 tests/palier1.py
> et corrige jusqu'à ce qu'il soit réussi. Montre-moi les 10 mots les plus fréquents de l'Apologie de Platon.

Regardez d'abord ce qui échoue : NFC et NFD, accent grave, apostrophe d'élision (`ʼ`, `’`, `'`), sigma final.
Puis regardez pourquoi `ὦ` est si fréquent dans l'Apologie.

### Palier 2 : Concordancier

> Palier 2 : écris concordance.py comme le décrit AGENTS.md, en réutilisant grec.py. Lance
> python3 tests/palier2.py. Puis montre-moi la concordance de ψυχ* : que remarques-tu entre Homère et Platon ?

Essayez `python3 concordance.py τεθναίην` (Socrate cite Achille), puis `Μίνως`, et regardez pourquoi l'Odyssée
n'apparaît pas.

### Palier 3 : Page web

> Palier 3 : construis la page web (construire_site.py, site/index.html, site/recherche.js) décrite dans
> AGENTS.md. Lance python3 tests/palier3.py, puis ouvre site/index.html avec ton navigateur et montre-la-moi.

Ouvrez la page vous-même, d'un double-clic sur `site/index.html` (sous WSL :
`explorer.exe "$(wslpath -w site/index.html)"`).

### Palier 4 : Lemmatisation avec Aristote

> Palier 4 : écris lemmatiser.py comme le décrit AGENTS.md (API Aristote en bibliothèque standard, clé jamais
> affichée, cache, vérification dans le LSJ et relance). Lance
> python3 lemmatiser.py tests/donnees/palier4.txt > sorties/palier4.tsv, puis python3 tests/palier4.py.

L'appel au modèle prend de quelques secondes à une minute par phrase. Le test, lui, lit seulement
`sorties/palier4.tsv` et n'appelle pas l'API : vous pouvez le relancer autant que vous voulez. Regardez quels mots
sont faux, et s'ils sont plutôt chez Homère ou chez Lysias.

### Palier 5 (bonus) : Serveur MCP

> Palier 5 : écris serveur_mcp.py comme le décrit AGENTS.md et lance python3 tests/palier5.py.

Puis quittez pi (`/exit`) et branchez le serveur :

```bash
pi mcp add corpus --exposure direct -- python3 "$PWD/serveur_mcp.py"
pi mcp list            # « corpus: connected, 2 tools » (ou plus)
pi
```

> Avec l'outil corpus, compare les emplois de ψυχή chez Homère et chez Platon.

Après le TP, débranchez-le avec `pi mcp remove corpus`.

## Bien piloter l'agent

- Un palier par demande : une demande trop vaste (« fais tout le TP ») tourne longtemps et se perd.
- Faites lancer le test et lisez sa sortie. Un `[ÉCHEC]` dit ce qui manque, souvent avec les points de code
  Unicode en cause.
- Relisez le code et `git diff`, vous êtes responsable de ce que l'agent écrit (`git checkout -- fichier`
  annule une modification).
- Tapez `/clear` entre deux paliers : le contexte est plus court et les réponses plus rapides.
- Échap interrompt l'agent. Si le modèle est lent, c'est sans doute que tout le monde l'interroge en même
  temps : patientez, ou changez de modèle avec `/model`.
- Avec `/socrate lance tous les tests et relis concordance.py`, un disciple relit à votre place, sans rien
  modifier.

## Pour aller plus loin

- Palier 1 : l'option `--sans-accents` (et pourquoi `η` devient le 4ᵉ mot), le tri alphabétique grec, la loi de Zipf
- Palier 2 : les voisins les plus fréquents de ψυχή
- Palier 3 : des liens vers The Greek Library depuis la page web
- Palier 4 : la comparaison des modèles d'Aristote, et la recherche par lemme (`Μίνωα`, Od. 11.568, et `Μίνως`,
  Ap. 41a)
- Palier 5 : les deux Apologies comparées par des sous-agents (`ultracode`)

## Le corpus

Textes de la Perseus Digital Library (CC BY-SA 4.0), dans les éditions de The Greek Library (voir
`corpus/LISEZMOI.md` et `corpus/LICENCE.md`). Ne modifiez ni `corpus/` ni `tests/`.
